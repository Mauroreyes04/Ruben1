<?php

namespace App\Models;
use App\Models\Apprentice;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User_Subjects extends Model
{
    use HasFactory;

    
}
