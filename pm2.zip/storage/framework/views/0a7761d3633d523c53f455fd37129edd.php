

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <form action="<?php echo e(route('instructores_store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h2>Registro de Instructores</h2>
                    <div class="form-group">
                        <label for="usuario">Seleccionar usuario:</label>
                        <select name="usuario" id="usuario" class="form-select" required>
                            <option value=""disabled selected>Elija un usuario</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?></option>   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cursos">Seleccionar curso:</label>
                        <select name="cursos" id="cursos" class="form-select" required>
                            <option value="" disabled selected>Elija un Curso</option>
                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div><br>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/instructores/register.blade.php ENDPATH**/ ?>