<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Editar Usuario</h1>

    <form action="<?php echo e(route('usuarios.update', $usuario->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($usuario->name); ?>">
        </div>

        <div class="form-group">
            <label for="documento">Documento</label>
            <input type="number" name="documento" id="documento" class="form-control" value="<?php echo e($usuario->document_number); ?>">
        </div>

        <div class="form-group">
            <label for="telefono">Teléfono</label>
            <input type="number" name="telefono" id="telefono" class="form-control" value="<?php echo e($usuario->telephone); ?>">
        </div>

        <div class="form-group">
            <label for="correo">Correo</label>
            <input type="text" name="correo" id="correo" class="form-control" value="<?php echo e($usuario->email); ?>">
        </div>

        <div class="form-group">
            <label for="contraseña">Contraseña</label>
            <input type="text" name="contraseña" id="contraseña" class="form-control" value="<?php echo e($usuario->password); ?>">
        </div>

        <div class="form-group">
            <label for="Genero">Género</label>
            <input type="text" name="Genero" id="Genero" class="form-control" value="<?php echo e($usuario->male); ?>">
        </div>

        <div class="form-group">
            <label for="Direccion">Dirección</label>
            <input type="text" name="Direccion" id="Direccion" class="form-control" value="<?php echo e($usuario->address); ?>">
        </div>

        <div class="form-group">
            <label for="Nacimiento">Fecha de Nacimiento</label>
            <input type="date" name="Nacimiento" id="Nacimiento" class="form-control" value="<?php echo e($usuario->age); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Guardar</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>