

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
        <table class="table">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Curso</th>
                    <th scope="col">Jornada</th>
                    <th scope="col">Fecha</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $instructores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($instructor->user_id); ?></th>
                    <th scope="row"><?php echo e($instructor->course_id); ?></th>
                    <th scope="row"><?php echo e($instructor->school_day); ?></th>
                    <th scope="row"><input type="date" name="fecha"></th>
                    <td>@mdo</td>
                    </tr>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/instructores/consulta.blade.php ENDPATH**/ ?>