

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <form action="<?php echo e(route('materias_store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <br>
    <div class="form-group">
        <label for="nombre">Nombre de la materia:</label>
        <input type="text" name="nombre" id="nombre" class="form-control">
    </div>

    <div class="form-group">
        <label for="curso">Curso:</label>
        <select name="cursos" id="cursos" class="form-select">
            <option value="" disabled selected>Elija un Curso</option>
            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($curso->id); ?>"><?php echo e($curso->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label for="usuario_id">Instructor</label>
        <select name="usuario_id" id="usuario_id" class="form-select">
            <option value=""  disabled selected>Elija un Usuario</option>
            <?php $__currentLoopData = $instructores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($instructor->user_id == $user->id): ?>
                <option value="<?php echo e($instructor->id); ?>"><?php echo e($user->name); ?></option>
                            <?php break; ?>
                            <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </select>
    </div><br>
    <button type="submit" class="btn btn-primary">Registrar</button>
</form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/instructores/materias.blade.php ENDPATH**/ ?>