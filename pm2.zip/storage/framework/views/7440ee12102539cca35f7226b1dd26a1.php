

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-9">
            <div class="card">
            <div class="row justify-content">
    <div class="col-md-5">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Aprendiz</th>
                    <th scope="col">Nota 1</th>
                    <th scope="col">Nota 2</th>
                    <th scope="col">Nota 3</th>
                    <th scope="col">Promedio</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $apprentice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?php echo e($instructor->id); ?></td>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprendiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($instructor->user_id == $aprendiz->id): ?>
                            <td><?php echo e($aprendiz->name); ?></td>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($instructor->curso_id == $curso->id): ?>
                            <td>
                                <input type="number" name="nota1" value="<?php echo e($instructor->nota1); ?>" placeholder="Nota 1">
                            </td>
                            <td>
                                <input type="number" name="nota2" value="<?php echo e($instructor->nota2); ?>" placeholder="Nota 2">
                            </td>
                            <td>
                                <input type="number" name="nota3" value="<?php echo e($instructor->nota3); ?>" placeholder="Nota 3">
                            </td>
                            <?php break; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <?php
                        $promedio = ($instructor->nota1 + $instructor->nota2 + $instructor->nota3) / 3;
                        echo number_format($promedio, 2);
                        ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
    
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/apprentices/notas.blade.php ENDPATH**/ ?>