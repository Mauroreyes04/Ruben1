

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
                <form action="<?php echo e(route('scores_search')); ?>" method="GET">
                    <div class="form-group">
                        <label for="documento">Buscar por número de documento:</label>
                        <input type="text" name="documento" id="documento" class="form-control" value="<?php echo e($documentsearch ?? ''); ?>">
                    </div><br>
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </form>
            </div>

            <?php if(isset($resultados)): ?>
                <div class="card">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="row">Documento</th>
                                <th scope="col">Nombre</th>
                                <th scope="col">Curso</th>
                                <th scope="col">Materia</th>
                                <th scope="col">Definitiva</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $apprentices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apprentice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($nota->apprentice_id == $apprentice->id): ?>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($apprentice->user_id == $user->id): ?>
                                                    <th><?php echo e($user->document_number); ?></th>
                                                    <th><?php echo e($user->name); ?></th>
                                                    <?php break; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($apprentice->curso_id == $curso->id): ?>
                                                    <th><?php echo e($curso->name); ?></th>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($nota->subject_id == $subject->id): ?>
                                            <th><?php echo e($subject->nombre); ?></th>
                                            <?php break; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <th scope="row"><?php echo e($nota->average); ?></th>
                                    <th><form action="<?php echo e(route('scores_download_pdf')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="documento" value="<?php echo e($documentsearch ?? ''); ?>">
                                    <button type="submit" class="btn btn-primary">Descargar PDF</button>
                                </form></th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/apprentices/consulta.blade.php ENDPATH**/ ?>