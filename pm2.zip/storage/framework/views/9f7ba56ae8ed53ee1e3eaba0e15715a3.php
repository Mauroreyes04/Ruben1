

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">

            <form action="<?php echo e(route('scores_store')); ?>" method="POST">
                <select name="materia" id="materia">
                    <option value="" disabled selected>Selecciona una Materia</option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="row">#</th>
                            <th>Aprendiz</th>
                            <th>Nota 1</th>
                            <th>Nota 2</th>
                            <th>Nota 3</th>
                            <th>Promedio</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $apprentices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apprentice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <input type="hidden" name="usuarioId" value="<?php echo e($apprentice->id); ?>">
                            <td><?php echo e($apprentice->id); ?></td>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($apprentice->user_id == $user->id): ?>
                            <td><?php echo e($user->name); ?></td>
                            <input type="hidden" name="documento" value="<?php echo e($user->document_number); ?>" style="width: 30%" readonly>
                            <?php break; ?>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <input type="number" class="nota" name="nota1" value="" oninput="calcularPromedio(this)">
                            </td>
                            <td>
                                <input type="number" class="nota" name="nota2" value="" oninput="calcularPromedio(this)">
                            </td>
                            <td>
                                <input type="number" class="nota" name="nota3" value="" oninput="calcularPromedio(this)">
                            </td>
                            <td>
                                <input type="number" class="promedio" name="promedio" value="" style="width: 30%" readonly>
                            </td>
                            <td><button type="submit" class="btn btn-primary">Guardar</button></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>
</div>

<script type="text/javascript">
    function calcularPromedio(input) {
        var row = input.closest('tr');
        var notas = row.getElementsByClassName('nota');
        var promedioInput = row.getElementsByClassName('promedio')[0];

        var suma = 0;
        var contador = 0;

        for (var i = 0; i < notas.length; i++) {
            var nota = parseFloat(notas[i].value);
            if (!isNaN(nota)) {
                suma += nota;
                contador++;
            }
        }

        if (contador > 0) {
            var promedio = suma / contador;
            promedioInput.value = promedio.toFixed(1);
        } else {
            promedioInput.value = '';
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/instructores/notas.blade.php ENDPATH**/ ?>