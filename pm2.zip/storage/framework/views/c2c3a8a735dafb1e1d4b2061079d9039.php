

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form action="<?php echo e(route('filter')); ?>" method="GET" >
                <div class="form-group">
                    <label for="fecha">Filtrar por Fecha:</label>
                    <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo e($fechaFiltro ?? ''); ?>">
                </div>
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </form>
            
            <table class="table table-sm table-bordered table-hover table-striped">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Id Usuario</th>
                        <th scope="col">Nombre</th>
                    </tr>
                </thead>
                <tbody>
    <?php $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($asistencia->id); ?></td>
        <td><?php echo e($asistencia->estado); ?></td>
        <td><?php echo e($asistencia->fecha); ?></td>
        <td><?php echo e($asistencia->id_usuario); ?></td>
        
        <?php $__currentLoopData = $aprendices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aprendiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($asistencia->id_usuario == $aprendiz->id): ?>
                <td><?php echo e($aprendiz->nombre); ?></td>
                <?php break; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pm2\resources\views/asistencia/consulta.blade.php ENDPATH**/ ?>